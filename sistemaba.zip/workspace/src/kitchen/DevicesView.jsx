import { motion } from 'framer-motion'
import { LogOut, MonitorSmartphone, RadioTower, Smartphone, UserX } from 'lucide-react'

function timeAgo(ts) {
  const secs = Math.max(0, Math.floor((Date.now() - ts) / 1000))
  if (secs < 60) return 'agora'
  const m = Math.floor(secs / 60)
  if (m < 60) return `há ${m} min`
  const h = Math.floor(m / 60)
  return `há ${h}h`
}

export default function DevicesView({ devices, send }) {
  const kickAllKitchens = () => {
    if (devices.filter((d) => d.role === 'kitchen').length === 0) return
    if (window.confirm('Expulsar todos os painéis da cozinha conectados?')) {
      for (const d of devices.filter((x) => x.role === 'kitchen')) {
        send('kick', { deviceId: d.id })
      }
    }
  }

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-5">
      <div className="mb-4 flex items-center justify-between">
        <p className="text-sm font-bold uppercase tracking-widest text-zinc-300">
          {devices.length} dispositivo{devices.length !== 1 ? 's' : ''} conectado
          {devices.length !== 1 ? 's' : ''}
        </p>
        <button
          onClick={kickAllKitchens}
          disabled={!devices.some((d) => d.role === 'kitchen')}
          className="glass flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-bold text-red-300 disabled:opacity-40"
        >
          <UserX className="h-4 w-4" />
          Expulsar todos os painéis
        </button>
      </div>

      {devices.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-2xl border border-dashed border-white/10 px-4 py-16 text-center">
          <RadioTower className="h-8 w-8 text-zinc-600" />
          <p className="text-sm text-zinc-600">
            Nenhum dispositivo conectado no momento.
          </p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {devices.map((d) => (
            <motion.div
              key={d.id}
              layout
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass flex items-center gap-3 rounded-2xl px-4 py-3"
            >
              <div
                className={`flex h-10 w-10 items-center justify-center rounded-xl ${
                  d.role === 'kitchen'
                    ? 'bg-red-500/15 text-red-400'
                    : 'bg-amber-400/10 text-amber-300'
                }`}
              >
                {d.role === 'kitchen' ? (
                  <MonitorSmartphone className="h-5 w-5" />
                ) : (
                  <Smartphone className="h-5 w-5" />
                )}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold text-white">{d.label}</p>
                <p className="text-[11px] text-zinc-500">
                  {d.role === 'kitchen' ? (
                    <span className="font-semibold text-red-400">Painel da cozinha</span>
                  ) : (
                    <span className="font-semibold text-amber-300">Cliente</span>
                  )}{' '}
                  · conectado {timeAgo(d.connectedAt)} · id #{d.id}
                </p>
              </div>
              <button
                onClick={() => {
                  if (window.confirm(`Remover "${d.label}" do sistema?`)) {
                    send('kick', { deviceId: d.id })
                  }
                }}
                className="flex items-center gap-1.5 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-1.5 text-xs font-bold text-red-400 hover:bg-red-500/20"
              >
                <LogOut className="h-3.5 w-3.5" />
                Remover
              </button>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  )
}
