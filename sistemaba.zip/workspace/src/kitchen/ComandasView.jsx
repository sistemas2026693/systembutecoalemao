import { AnimatePresence, motion } from 'framer-motion'
import { Banknote, HandCoins, Receipt, Users } from 'lucide-react'
import { formatBRL } from '../menu.js'

function StatusBadge({ status }) {
  if (status === 'pending') {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-full border border-red-500/50 bg-red-500/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-red-400 animate-pulse-dot">
        <Banknote className="h-3 w-3" />
        Aguardando pagamento
      </span>
    )
  }
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-400/40 bg-amber-400/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-amber-300">
      <span className="h-1.5 w-1.5 rounded-full bg-amber-400" />
      Em aberto
    </span>
  )
}

export default function ComandasView({ comandas, onClose, onPay }) {
  const openTotal = comandas.filter((c) => c.status === 'open').reduce((s, c) => s + c.total, 0)
  const pendingTotal = comandas
    .filter((c) => c.status === 'pending')
    .reduce((s, c) => s + c.total, 0)

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-5">
      <div className="mb-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div className="flex items-center gap-3 rounded-2xl border border-white/5 bg-white/[0.03] px-4 py-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-400/15">
            <Users className="h-5 w-5 text-amber-300" />
          </div>
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-widest text-zinc-500">
              Em aberto
            </p>
            <p className="text-lg font-extrabold text-amber-400">{formatBRL(openTotal)}</p>
          </div>
        </div>
        <div className="flex items-center gap-3 rounded-2xl border border-red-500/20 bg-red-500/[0.06] px-4 py-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-red-500/15">
            <HandCoins className="h-5 w-5 text-red-400" />
          </div>
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-widest text-zinc-500">
              Aguardando pagamento
            </p>
            <p className="text-lg font-extrabold text-red-400">{formatBRL(pendingTotal)}</p>
          </div>
        </div>
      </div>

      {comandas.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-2xl border border-dashed border-white/10 px-4 py-16 text-center">
          <Receipt className="h-8 w-8 text-zinc-600" />
          <p className="text-sm text-zinc-600">
            Nenhuma comanda aberta. Os pedidos aparecem aqui agrupados por mesa.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="popLayout">
            {comandas.map((c) => (
              <motion.div
                key={c.table}
                layout
                initial={{ opacity: 0, scale: 0.92, y: 16 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.85, y: -16 }}
                transition={{ type: 'spring', stiffness: 300, damping: 26 }}
                className={`glass overflow-hidden rounded-2xl ${
                  c.status === 'pending' ? 'ring-2 ring-red-500/40 shadow-glowred' : ''
                }`}
              >
                <div className="flex items-center justify-between border-b border-white/5 px-4 py-3">
                  <div className="flex items-center gap-2">
                    <span className="font-display text-2xl tracking-wide text-gold-grad">
                      Mesa {c.table}
                    </span>
                    <span className="rounded-md bg-white/5 px-1.5 py-0.5 text-[10px] font-semibold text-zinc-400">
                      {c.orderCount} pedido{c.orderCount > 1 ? 's' : ''}
                    </span>
                  </div>
                  <StatusBadge status={c.status} />
                </div>

                <div className="px-4 py-3">
                  <p className="text-xs text-zinc-500">
                    Cliente: <span className="font-semibold text-zinc-300">{c.customerName}</span>
                  </p>
                  <div className="mt-2.5 space-y-1">
                    {c.items.map((item) => (
                      <div key={item.id} className="flex items-center gap-2 text-sm">
                        <span className="w-5 shrink-0 text-right font-bold text-amber-300">
                          {item.qty}×
                        </span>
                        <span className="text-xs">{item.emoji}</span>
                        <span className="truncate text-zinc-300">{item.name}</span>
                        <span className="ml-auto text-xs text-zinc-500">
                          {formatBRL(item.price * item.qty)}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="mt-3 flex items-center justify-between border-t border-white/5 pt-3">
                    <span className="text-xs uppercase tracking-widest text-zinc-500">Total</span>
                    <span className="text-lg font-extrabold text-amber-400">
                      {formatBRL(c.total)}
                    </span>
                  </div>
                </div>

                <div className="px-4 pb-3">
                  {c.status === 'open' ? (
                    <button
                      onClick={() => onClose(c.table)}
                      className="flex w-full items-center justify-center gap-2 rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-2.5 text-xs font-bold tracking-wide text-red-300 transition hover:bg-red-500/20 active:scale-[0.97]"
                    >
                      <Banknote className="h-4 w-4" />
                      Fechar comanda
                    </button>
                  ) : (
                    <button
                      onClick={() => onPay(c.table)}
                      className="btn-gold flex w-full items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold tracking-wide active:scale-[0.97]"
                    >
                      <HandCoins className="h-4 w-4" />
                      Confirmar pagamento
                    </button>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  )
}
