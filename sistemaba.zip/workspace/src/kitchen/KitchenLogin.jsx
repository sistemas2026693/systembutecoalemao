import { useState } from 'react'
import { motion } from 'framer-motion'
import { Lock, LogIn } from 'lucide-react'

export default function KitchenLogin({ error, onUnlock }) {
  const [value, setValue] = useState('')

  const submit = (e) => {
    e.preventDefault()
    if (!value.trim()) return
    onUnlock(value.trim())
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-coal/95 px-6 backdrop-blur">
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ type: 'spring', stiffness: 260, damping: 22 }}
        className="w-full max-w-sm rounded-3xl border border-white/10 bg-carbon p-8 text-center"
      >
        <img
          src="/logo.svg"
          alt="Logo"
          className="mx-auto h-14 w-14 drop-shadow-[0_0_18px_rgba(255,193,7,0.4)]"
        />
        <h2 className="mt-4 font-display text-2xl tracking-wide text-white">
          PAINEL DA <span className="text-gold-grad">COZINHA</span>
        </h2>
        <p className="mt-1 text-xs text-zinc-500">Digite o PIN de acesso do balcão.</p>

        <form onSubmit={submit} className="mt-6">
          <input
            autoFocus
            type="password"
            inputMode="numeric"
            autoComplete="off"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder="••••"
            className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3.5 text-center text-2xl tracking-[0.6em] text-white placeholder-zinc-600 outline-none focus:border-amber-400/60"
          />
          <button
            type="submit"
            disabled={!value.trim()}
            className="btn-red mt-4 flex w-full items-center justify-center gap-2 rounded-2xl px-6 py-3.5 text-sm font-bold tracking-wide disabled:opacity-40"
          >
            <LogIn className="h-4 w-4" />
            Entrar no painel
          </button>
        </form>

        {error && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-3 flex items-center justify-center gap-1.5 text-xs font-semibold text-red-400"
          >
            <Lock className="h-3.5 w-3.5" />
            PIN incorreto. Tente novamente.
          </motion.p>
        )}

        <button
          onClick={() => (window.location.hash = '#/')}
          className="mt-6 text-xs font-semibold text-zinc-500 hover:text-zinc-300"
        >
          Voltar ao início
        </button>
      </motion.div>
    </div>
  )
}
