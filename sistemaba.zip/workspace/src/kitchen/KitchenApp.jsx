import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  Bell,
  ChevronLeft,
  ClipboardList,
  Clock,
  HandCoins,
  MonitorSmartphone,
  Plus,
  Receipt,
  Utensils
} from 'lucide-react'
import { useSocket } from '../lib/useSocket.js'
import { getDeviceName } from '../lib/device.js'
import { playNewOrderChime, playPaymentSound } from '../lib/sound.js'
import KickedOverlay from '../components/KickedOverlay.jsx'
import KitchenLogin from './KitchenLogin.jsx'
import OrderCard from './OrderCard.jsx'
import ComandasView from './ComandasView.jsx'
import CardapioAdmin from './CardapioAdmin.jsx'
import DevicesView from './DevicesView.jsx'

const COLUMNS = [
  { key: 'new', label: 'Novos', dot: 'bg-[#E50914]', empty: 'Aguardando novos pedidos…' },
  { key: 'preparing', label: 'Preparando', dot: 'bg-[#FFC107]', empty: 'Nada no fogo agora.' },
  { key: 'ready', label: 'Prontos', dot: 'bg-emerald-400', empty: 'Nada pronto no momento.' }
]

const NEXT_ACTION = {
  new: { label: 'Iniciar preparo', status: 'preparing', icon: Clock },
  preparing: { label: 'Marcar pronto', status: 'ready', icon: Plus },
  ready: { label: 'Entregar', status: 'delivered', icon: Plus }
}

const TABS = [
  { key: 'pedidos', label: 'Pedidos', icon: ClipboardList },
  { key: 'comandas', label: 'Comandas', icon: Receipt },
  { key: 'cardapio', label: 'Cardápio', icon: Utensils },
  { key: 'dispositivos', label: 'Dispositivos', icon: MonitorSmartphone }
]

const KITCHEN_LABEL = `Painel da Cozinha · ${getDeviceName()}`

function elapsedLabel(createdAt) {
  const secs = Math.max(0, Math.floor((Date.now() - createdAt) / 1000))
  const m = Math.floor(secs / 60)
  const s = secs % 60
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
}

export default function KitchenApp() {
  const [view, setView] = useState('pedidos')
  const [orders, setOrders] = useState([])
  const [comandas, setComandas] = useState([])
  const [menu, setMenu] = useState(null)
  const [devices, setDevices] = useState([])
  const [flashIds, setFlashIds] = useState({})
  const [toast, setToast] = useState(null)
  const [kicked, setKicked] = useState(false)
  const [now, setNow] = useState(Date.now())
  const [authed, setAuthed] = useState(() => !!sessionStorage.getItem('buteco_pin'))
  const [pinError, setPinError] = useState(false)

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 30000)
    return () => clearInterval(timer)
  }, [])

  const { send, disconnect } = useSocket(
    (msg) => {
      if (msg.type === 'sync') {
        setOrders(msg.payload.orders || [])
        setComandas(msg.payload.comandas || [])
        setMenu(msg.payload.menu)
        return
      }
      if (msg.type === 'comandas') {
        setComandas(msg.payload.comandas || [])
        return
      }
      if (msg.type === 'menu') {
        setMenu(msg.payload.menu)
        return
      }
      if (msg.type === 'devices') {
        setDevices(msg.payload.devices || [])
        return
      }
      if (msg.type === 'kicked') {
        setKicked(true)
        disconnect()
        return
      }
      if (msg.type === 'auth_error') {
        setAuthed(false)
        setPinError(true)
        return
      }
      if (msg.type === 'identified') {
        setAuthed(true)
        setPinError(false)
        return
      }
      if (msg.type === 'comanda_closed') {
        setToast({ type: 'payment', table: msg.payload.table })
        setTimeout(() => setToast(null), 5000)
        playPaymentSound()
        return
      }
      if (msg.type === 'order_placed') {
        const order = msg.payload.order
        setOrders((o) => [order, ...o.filter((x) => x.id !== order.id)])
        setFlashIds((f) => ({ ...f, [order.id]: true }))
        setTimeout(() => setFlashIds((f) => ({ ...f, [order.id]: false })), 2000)
        setToast(order)
        setTimeout(() => setToast(null), 5000)
        playNewOrderChime()
        return
      }
      if (msg.type === 'order_updated') {
        const order = msg.payload.order
        setOrders((o) => o.map((x) => (x.id === order.id ? order : x)))
        return
      }
      if (msg.type === 'order_removed') {
        setOrders((o) => o.filter((x) => x.id !== msg.payload.orderId))
      }
    },
    { role: 'kitchen', label: KITCHEN_LABEL, pin: sessionStorage.getItem('buteco_pin') || undefined }
  )

  const unlock = (value) => {
    sessionStorage.setItem('buteco_pin', value)
    setPinError(false)
    setAuthed(true)
    send('identify', { role: 'kitchen', label: KITCHEN_LABEL, pin: value })
  }

  const updateStatus = (orderId, status) => send('update_status', { orderId, status })
  const closeComanda = (table) => send('close_comanda', { table })
  const payComanda = (table) => send('confirm_payment', { table })

  const counts = COLUMNS.map((c) => ({
    ...c,
    items: orders.filter((o) => o.status === c.key),
    count: orders.filter((o) => o.status === c.key).length
  }))
  const totalActive = orders.length
  const openComandas = comandas.filter((c) => c.status !== 'paid').length

  const counterLabel = {
    pedidos: `${totalActive} ativos`,
    comandas: `${openComandas} comandas`,
    cardapio: `${menu?.items?.length ?? 0} itens`,
    dispositivos: `${devices.length} disp`
  }[view]

  if (kicked) return <KickedOverlay />

  if (!authed) return <KitchenLogin error={pinError} onUnlock={unlock} />

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-30 border-b border-white/5 bg-coal/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3.5">
          <div className="flex items-center gap-3">
            <button
              onClick={() => (window.location.hash = '#/')}
              className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-zinc-300"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <img
              src="/logo.svg"
              alt="Logo"
              className="h-10 w-10 drop-shadow-[0_0_14px_rgba(255,193,7,0.35)]"
            />
            <div>
              <p className="font-display text-xl leading-none tracking-wide text-white">
                PAINEL DA <span className="text-gold-grad">COZINHA</span>
              </p>
              <p className="text-[10px] font-medium uppercase tracking-widest text-zinc-500">
                Balcão do Buteco do Alemão
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="hidden items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 sm:flex">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse-dot" />
              <span className="text-[11px] font-semibold text-zinc-300">Conectado</span>
            </div>
            <div className="rounded-xl border border-white/10 bg-white/5 px-3.5 py-2 text-xs font-bold text-amber-300">
              {counterLabel}
            </div>
          </div>
        </div>

        <div className="no-scrollbar mx-auto flex max-w-7xl gap-1.5 overflow-x-auto px-4 pb-3">
          {TABS.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setView(key)}
              className={`flex shrink-0 items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold tracking-wide transition ${
                view === key
                  ? 'bg-gradient-to-r from-[#E50914] to-[#FF3B30] text-white shadow-glowred'
                  : 'border border-white/10 bg-white/5 text-zinc-400 hover:text-white'
              }`}
            >
              <Icon className="h-4 w-4" />
              {label}
            </button>
          ))}
        </div>
      </header>

      <AnimatePresence>
        {toast && (
          <motion.div
            key={toast.type === 'payment' ? `pay-${toast.table}` : toast.id}
            initial={{ opacity: 0, y: -60, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -60, scale: 0.9 }}
            transition={{ type: 'spring', stiffness: 300, damping: 24 }}
            className="fixed left-1/2 top-4 z-50 w-[calc(100%-2rem)] max-w-md -translate-x-1/2"
          >
            {toast.type === 'payment' ? (
              <div className="bg-live flex items-center gap-3 rounded-2xl px-4 py-3.5 text-white shadow-2xl">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-black/20">
                  <HandCoins className="h-5 w-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-extrabold tracking-wide">PAGAMENTO CONFIRMADO</p>
                  <p className="truncate text-xs text-white/80">
                    Comanda da mesa {toast.table} encerrada com sucesso.
                  </p>
                </div>
              </div>
            ) : (
              <div className="bg-live flex items-center gap-3 rounded-2xl px-4 py-3.5 text-white shadow-2xl">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-black/20">
                  <Bell className="h-5 w-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-extrabold tracking-wide">NOVO PEDIDO #{toast.id}</p>
                  <p className="truncate text-xs text-white/80">
                    Mesa {toast.table} · {toast.customerName} ·{' '}
                    {toast.items.reduce((s, i) => s + i.qty, 0)} itens
                  </p>
                </div>
                <span className="shrink-0 rounded-lg bg-black/20 px-2 py-1 text-xs font-bold">
                  🔔
                </span>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      <main className="flex-1">
        {view === 'comandas' && (
          <ComandasView comandas={comandas} onClose={closeComanda} onPay={payComanda} />
        )}
        {view === 'cardapio' && menu && <CardapioAdmin menu={menu} send={send} />}
        {view === 'dispositivos' && <DevicesView devices={devices} send={send} />}
        {view === 'pedidos' && (
          <div className="mx-auto w-full max-w-7xl px-4 py-5">
            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
              {counts.map((col) => (
                <div
                  key={col.key}
                  className="flex flex-col rounded-2xl border border-white/5 bg-white/[0.02]"
                >
                  <div className="flex items-center justify-between border-b border-white/5 px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      <span className={`h-2.5 w-2.5 rounded-full ${col.dot}`} />
                      <span className="text-sm font-bold uppercase tracking-widest text-zinc-200">
                        {col.label}
                      </span>
                    </div>
                    <span className="flex h-6 min-w-6 items-center justify-center rounded-full bg-white/5 px-2 text-xs font-bold text-zinc-300">
                      {col.count}
                    </span>
                  </div>

                  <div className="flex flex-col gap-3 p-3">
                    <AnimatePresence>
                      {col.items.length === 0 && (
                        <motion.div
                          key="empty"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="flex flex-col items-center gap-2 rounded-xl border border-dashed border-white/10 px-4 py-10 text-center"
                        >
                          <span className="text-2xl">🍻</span>
                          <p className="text-xs text-zinc-600">{col.empty}</p>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    <AnimatePresence mode="popLayout">
                      {col.items.map((order) => (
                        <OrderCard
                          key={order.id}
                          order={order}
                          flash={!!flashIds[order.id]}
                          elapsed={elapsedLabel(order.createdAt)}
                          action={NEXT_ACTION[order.status]}
                          onAction={() =>
                            updateStatus(order.id, NEXT_ACTION[order.status].status)
                          }
                        />
                      ))}
                    </AnimatePresence>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
