import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Check, Pencil, Plus, Trash2, X } from 'lucide-react'
import { formatBRL } from '../menu.js'

const inputCls =
  'w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-white placeholder-zinc-500 outline-none focus:border-amber-400/60'

export default function CardapioAdmin({ menu, send }) {
  const [newItem, setNewItem] = useState({
    name: '',
    desc: '',
    price: '',
    emoji: '🍽️',
    category: menu?.categories?.[0]?.id || ''
  })
  const [newCat, setNewCat] = useState({ name: '', emoji: '' })
  const [editId, setEditId] = useState(null)
  const [editForm, setEditForm] = useState(null)

  const setNew = (k) => (e) => setNewItem((f) => ({ ...f, [k]: e.target.value }))
  const setCat = (k) => (e) => setNewCat((f) => ({ ...f, [k]: e.target.value }))

  const addItem = () => {
    if (!newItem.name.trim() || !newItem.price) return
    send('add_item', {
      item: {
        name: newItem.name.trim(),
        desc: newItem.desc.trim(),
        price: Number(newItem.price),
        emoji: newItem.emoji.trim() || '🍽️',
        category: newItem.category || menu.categories[0]?.id
      }
    })
    setNewItem({ name: '', desc: '', price: '', emoji: '🍽️', category: newItem.category })
  }

  const addCategory = () => {
    if (!newCat.name.trim()) return
    send('add_category', { name: newCat.name.trim(), emoji: newCat.emoji.trim() || '🍽️' })
    setNewCat({ name: '', emoji: '' })
  }

  const startEdit = (item) => {
    setEditId(item.id)
    setEditForm({ ...item })
  }
  const setEdit = (k) => (e) => setEditForm((f) => ({ ...f, [k]: e.target.value }))
  const saveEdit = () => {
    send('update_item', { item: { ...editForm, price: Number(editForm.price) } })
    setEditId(null)
    setEditForm(null)
  }

  const catCount = (id) => menu.items.filter((i) => i.category === id).length

  return (
    <div className="mx-auto w-full max-w-5xl px-4 py-5">
      <div className="rounded-2xl border border-amber-400/20 bg-amber-400/[0.06] px-4 py-3 text-xs text-amber-200/90">
        As alterações aqui são salvas no servidor e aparecem na hora no cardápio dos clientes.
      </div>

      <div className="mt-4 rounded-2xl border border-white/5 bg-white/[0.03] p-4">
        <p className="mb-3 text-sm font-bold uppercase tracking-widest text-zinc-300">
          Adicionar item
        </p>
        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
          <input
            value={newItem.emoji}
            onChange={setNew('emoji')}
            placeholder="🍺"
            className={`${inputCls} text-center`}
          />
          <input
            value={newItem.name}
            onChange={setNew('name')}
            placeholder="Nome do item"
            className={inputCls}
          />
          <input
            value={newItem.price}
            onChange={setNew('price')}
            placeholder="Preço (R$)"
            type="number"
            min="0"
            step="0.10"
            className={inputCls}
          />
          <select value={newItem.category} onChange={setNew('category')} className={inputCls}>
            {menu.categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.emoji} {c.name}
              </option>
            ))}
          </select>
        </div>
        <input
          value={newItem.desc}
          onChange={setNew('desc')}
          placeholder="Descrição (opcional)"
          className={`${inputCls} mt-2.5`}
        />
        <button
          onClick={addItem}
          disabled={!newItem.name.trim() || !newItem.price}
          className="btn-red mt-3 flex items-center gap-2 rounded-xl px-5 py-2.5 text-xs font-bold tracking-wide disabled:opacity-40"
        >
          <Plus className="h-4 w-4" />
          Adicionar ao cardápio
        </button>
      </div>

      <div className="mt-3 flex items-end gap-2.5 rounded-2xl border border-white/5 bg-white/[0.03] p-4">
        <input
          value={newCat.emoji}
          onChange={setCat('emoji')}
          placeholder="🍷"
          className={`${inputCls} w-20 text-center`}
        />
        <input
          value={newCat.name}
          onChange={setCat('name')}
          placeholder="Nome da nova categoria"
          className={inputCls}
        />
        <button
          onClick={addCategory}
          disabled={!newCat.name.trim()}
          className="glass flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold text-amber-300 disabled:opacity-40"
        >
          <Plus className="h-4 w-4" />
          Criar categoria
        </button>
      </div>

      <div className="mt-6 space-y-6">
        {menu.categories.map((cat) => {
          const catItems = menu.items.filter((i) => i.category === cat.id)
          return (
            <div key={cat.id}>
              <div className="flex items-center gap-2.5">
                <span className="text-lg">{cat.emoji}</span>
                <h3 className="font-display text-xl tracking-wide text-white">{cat.name}</h3>
                <span className="rounded-full bg-white/5 px-2 py-0.5 text-[11px] font-bold text-zinc-400">
                  {catCount(cat.id)}
                </span>
                <button
                  onClick={() => {
                    if (window.confirm(`Apagar a categoria "${cat.name}" e todos os itens dela?`)) {
                      send('remove_category', { id: cat.id })
                    }
                  }}
                  className="ml-auto flex h-7 w-7 items-center justify-center rounded-lg border border-red-500/30 bg-red-500/10 text-red-400 hover:bg-red-500/20"
                  title="Apagar categoria"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>

              <div className="mt-2 space-y-2">
                <AnimatePresence>
                  {catItems.map((item) =>
                    editId === item.id ? (
                      <motion.div
                        key={item.id}
                        layout
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="rounded-xl border border-amber-400/30 bg-amber-400/[0.05] p-3"
                      >
                        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                          <input value={editForm.emoji} onChange={setEdit('emoji')} className={`${inputCls} text-center`} />
                          <input value={editForm.name} onChange={setEdit('name')} className={inputCls} />
                          <input value={editForm.price} onChange={setEdit('price')} type="number" className={inputCls} />
                          <select value={editForm.category} onChange={setEdit('category')} className={inputCls}>
                            {menu.categories.map((c) => (
                              <option key={c.id} value={c.id}>
                                {c.emoji} {c.name}
                              </option>
                            ))}
                          </select>
                        </div>
                        <input value={editForm.desc} onChange={setEdit('desc')} className={`${inputCls} mt-2`} />
                        <div className="mt-2 flex gap-2">
                          <button
                            onClick={saveEdit}
                            className="btn-gold flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold"
                          >
                            <Check className="h-3.5 w-3.5" />
                            Salvar
                          </button>
                          <button
                            onClick={() => setEditId(null)}
                            className="glass flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold text-zinc-300"
                          >
                            <X className="h-3.5 w-3.5" />
                            Cancelar
                          </button>
                        </div>
                      </motion.div>
                    ) : (
                      <motion.div
                        key={item.id}
                        layout
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="glass flex items-center gap-3 rounded-xl px-3 py-2.5"
                      >
                        <span className="text-xl">{item.emoji}</span>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-semibold text-white">{item.name}</p>
                          <p className="truncate text-xs text-zinc-500">{item.desc}</p>
                        </div>
                        <span className="text-sm font-bold text-amber-400">
                          {formatBRL(item.price)}
                        </span>
                        <button
                          onClick={() => startEdit(item)}
                          className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-zinc-300 hover:text-white"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => {
                            if (window.confirm(`Apagar "${item.name}" do cardápio?`)) {
                              send('remove_item', { id: item.id })
                            }
                          }}
                          className="flex h-8 w-8 items-center justify-center rounded-lg border border-red-500/30 bg-red-500/10 text-red-400 hover:bg-red-500/20"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </motion.div>
                    )
                  )}
                </AnimatePresence>

                {catItems.length === 0 && (
                  <p className="px-1 text-xs text-zinc-600">Categoria vazia.</p>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
