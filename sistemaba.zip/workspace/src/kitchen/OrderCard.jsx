import { motion } from 'framer-motion'
import { Timer } from 'lucide-react'
import { formatBRL } from '../menu.js'

const STATUS_STYLE = {
  new: 'from-[#E50914] to-[#FF3B30]',
  preparing: 'from-[#FFC107] to-[#FF9F1A]',
  ready: 'from-emerald-500 to-emerald-400'
}

export default function OrderCard({ order, flash, elapsed, action, onAction }) {
  const ActionIcon = action.icon

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 24, scale: 0.94 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.15 } }}
      transition={{ type: 'spring', stiffness: 320, damping: 26 }}
      className={`glass overflow-hidden rounded-2xl ${flash ? 'animate-flash' : ''}`}
    >
      <div className="flex items-center justify-between border-b border-white/5 px-4 py-3">
        <div className="flex items-center gap-2">
          <span
            className={`bg-gradient-to-br ${STATUS_STYLE[order.status]} flex h-7 min-w-7 items-center justify-center rounded-lg px-1.5 font-display text-sm tracking-wide text-white`}
          >
            #{order.id}
          </span>
          <span className="rounded-md bg-white/5 px-2 py-0.5 text-[11px] font-semibold text-zinc-300">
            Mesa {order.table}
          </span>
        </div>
        <div className="flex items-center gap-1.5 text-xs font-medium text-zinc-400">
          <Timer className="h-3.5 w-3.5 text-amber-400" />
          {elapsed}
        </div>
      </div>

      <div className="px-4 py-3">
        <p className="text-sm font-semibold text-white">
          {order.customerName}
          <span className="ml-2 text-xs font-normal text-zinc-500">
            {formatBRL(order.total)}
          </span>
        </p>

        <div className="mt-2 space-y-1">
          {order.items.map((item) => (
            <div key={item.id} className="flex items-center gap-2 text-sm">
              <span className="w-5 shrink-0 text-right font-bold text-amber-300">
                {item.qty}×
              </span>
              <span className="text-xs">{item.emoji}</span>
              <span className="truncate text-zinc-300">{item.name}</span>
            </div>
          ))}
        </div>

        {order.notes && (
          <p className="mt-2 rounded-lg bg-amber-400/10 px-2.5 py-1.5 text-xs text-amber-200/90">
            Obs: {order.notes}
          </p>
        )}
      </div>

      <div className="px-4 pb-3">
        <button
          onClick={onAction}
          className={`flex w-full items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold tracking-wide transition active:scale-[0.97] ${
            order.status === 'ready'
              ? 'btn-gold'
              : 'border border-amber-400/40 bg-amber-400/10 text-amber-300 hover:bg-amber-400/20'
          }`}
        >
          <ActionIcon className="h-4 w-4" />
          {action.label}
        </button>
      </div>
    </motion.div>
  )
}
