import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Minus, Plus, Send, Trash2, X } from 'lucide-react'
import { formatBRL } from '../menu.js'

export default function CartSheet({ open, onClose, items, total, onRemove, onAdd, onSubmit }) {
  const [name, setName] = useState('')
  const [table, setTable] = useState('')
  const [notes, setNotes] = useState('')
  const [error, setError] = useState('')

  const submit = () => {
    if (!name.trim()) return setError('Digite seu nome')
    if (!table) return setError('Escolha a mesa')
    setError('')
    onSubmit({ customerName: name.trim(), table, notes: notes.trim() })
  }

  const canSubmit = items.length > 0

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
          />
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', stiffness: 320, damping: 32 }}
            className="absolute inset-x-0 bottom-0 mx-auto max-w-2xl overflow-hidden rounded-t-3xl border-t border-white/10 bg-carbon"
          >
            <div className="mx-auto mt-3 h-1 w-12 rounded-full bg-white/15" />

            <div className="flex items-center justify-between px-5 pb-1 pt-4">
              <h2 className="font-display text-2xl tracking-wide text-white">SEU PEDIDO</h2>
              <button
                onClick={onClose}
                className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-zinc-400"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="max-h-[46vh] overflow-y-auto px-5">
              {canSubmit ? (
                <div className="divide-y divide-white/5">
                  {items.map(({ item, qty }) => (
                    <div key={item.id} className="flex items-center gap-3 py-3">
                      <span className="text-2xl">{item.emoji}</span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold text-white">{item.name}</p>
                        <p className="text-xs text-zinc-500">
                          {formatBRL(item.price)} cada
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => onRemove(item.id)}
                          className="flex h-7 w-7 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-zinc-300 active:scale-90"
                        >
                          {qty === 1 ? <Trash2 className="h-3.5 w-3.5" /> : <Minus className="h-3.5 w-3.5" />}
                        </button>
                        <span className="w-5 text-center text-sm font-bold text-white">{qty}</span>
                        <button
                          onClick={() => onAdd(item.id)}
                          className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-[#E50914] to-[#FF3B30] text-white active:scale-90"
                        >
                          <Plus className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="py-10 text-center text-sm text-zinc-500">
                  Seu carrinho está vazio. Adicione itens pelo cardápio!
                </p>
              )}

              <div className="mt-2 space-y-2.5 pb-2">
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Seu nome"
                  className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder-zinc-500 outline-none focus:border-amber-400/60"
                />
                <div className="grid grid-cols-2 gap-2.5">
                  <select
                    value={table}
                    onChange={(e) => setTable(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white outline-none focus:border-amber-400/60"
                  >
                    <option value="">Mesa</option>
                    {Array.from({ length: 15 }, (_, i) => i + 1).map((n) => (
                      <option key={n} value={n}>
                        Mesa {n}
                      </option>
                    ))}
                    <option value="balcao">Balcão</option>
                  </select>
                  <div className="flex items-center justify-center rounded-xl border border-white/5 bg-white/[0.03] text-sm text-zinc-500">
                    Retirada no balcão
                  </div>
                </div>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Observações (opcional) — ex: sem cebola, chopp extra gelado…"
                  rows={2}
                  className="w-full resize-none rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder-zinc-500 outline-none focus:border-amber-400/60"
                />
              </div>
            </div>

            <div className="border-t border-white/5 px-5 py-4">
              <div className="mb-3 flex items-center justify-between">
                <span className="text-sm text-zinc-400">Total</span>
                <span className="text-lg font-extrabold text-amber-400">{formatBRL(total)}</span>
              </div>
              {error && <p className="mb-2 text-xs font-medium text-red-400">{error}</p>}
              <button
                onClick={submit}
                disabled={!canSubmit}
                className="btn-red flex w-full items-center justify-center gap-2 rounded-2xl px-6 py-4 text-sm font-bold tracking-wide disabled:cursor-not-allowed disabled:opacity-40"
              >
                <Send className="h-4.5 w-4.5" />
                Enviar pedido para o balcão
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  )
}
