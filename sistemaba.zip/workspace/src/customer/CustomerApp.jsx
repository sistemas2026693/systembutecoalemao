import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ChevronLeft, Loader2, Plus, ShoppingBag } from 'lucide-react'
import { formatBRL } from '../menu.js'
import { useSocket } from '../lib/useSocket.js'
import { getDeviceName } from '../lib/device.js'
import { playPlacedSound } from '../lib/sound.js'
import KickedOverlay from '../components/KickedOverlay.jsx'
import CartSheet from './CartSheet.jsx'
import OrderStatusView from './OrderStatusView.jsx'

const CLIENT_LABEL = `Cliente · ${getDeviceName()}`

export default function CustomerApp() {
  const [menu, setMenu] = useState(null)
  const [activeCat, setActiveCat] = useState(null)
  const [cart, setCart] = useState({})
  const [sheetOpen, setSheetOpen] = useState(false)
  const [order, setOrder] = useState(null)
  const [comanda, setComanda] = useState(null)
  const [notice, setNotice] = useState(null)
  const [kicked, setKicked] = useState(false)

  const { send, disconnect } = useSocket(
    (msg) => {
      if (msg.type === 'sync' || msg.type === 'menu') {
        setMenu(msg.payload.menu)
        setActiveCat((c) => c || msg.payload.menu?.categories?.[0]?.id || null)
      }
      if (msg.type === 'placed') {
        setOrder(msg.payload.order)
      }
      if (msg.type === 'order_updated' && order && msg.payload.order.id === order.id) {
        setOrder(msg.payload.order)
      }
      if (msg.type === 'order_removed' && order && msg.payload.orderId === order.id) {
        setOrder((o) => (o ? { ...o, status: 'delivered' } : o))
      }
      if (
        msg.type === 'comanda_updated' &&
        order &&
        String(msg.payload.table) === String(order.table)
      ) {
        setComanda({ status: 'pending' })
      }
      if (
        msg.type === 'comanda_closed' &&
        order &&
        String(msg.payload.table) === String(order.table)
      ) {
        setComanda({ status: 'paid' })
      }
      if (msg.type === 'comanda_blocked') {
        setNotice(msg.payload.message)
        setTimeout(() => setNotice(null), 5000)
      }
      if (msg.type === 'kicked') {
        setKicked(true)
        disconnect()
      }
    },
    { role: 'client', label: CLIENT_LABEL }
  )

  const categories = menu?.categories || []
  const items = (menu?.items || []).filter((m) => m.category === activeCat)

  const add = (id) => setCart((c) => ({ ...c, [id]: (c[id] || 0) + 1 }))
  const remove = (id) =>
    setCart((c) => {
      const next = { ...c }
      if (next[id] <= 1) delete next[id]
      else next[id] -= 1
      return next
    })

  const cartItems = useMemo(
    () =>
      Object.entries(cart)
        .map(([id, qty]) => ({ item: menu?.items?.find((m) => m.id === id), qty }))
        .filter(({ item }) => item),
    [cart, menu]
  )
  const count = cartItems.reduce((s, { qty }) => s + qty, 0)
  const total = cartItems.reduce((s, { item, qty }) => s + item.price * qty, 0)

  const handleOrder = ({ customerName, table, notes }) => {
    send('place_order', {
      customerName,
      table,
      notes,
      total,
      items: cartItems.map(({ item, qty }) => ({
        id: item.id,
        name: item.name,
        price: item.price,
        qty,
        emoji: item.emoji
      }))
    })
    playPlacedSound()
    setOrder({ status: 'new' })
    setSheetOpen(false)
    setCart({})
  }

  const backToMenu = () => {
    setOrder(null)
    setComanda(null)
    setActiveCat(categories[0]?.id)
  }

  if (kicked) return <KickedOverlay />

  if (!menu) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center px-6 text-center">
        <img src="/logo.svg" alt="Logo" className="h-20 w-20 opacity-80" />
        <div className="mt-6 flex items-center gap-2 text-sm text-zinc-400">
          <Loader2 className="h-4 w-4 animate-spin text-amber-400" />
          Carregando cardápio…
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen pb-36">
      {order ? (
        <OrderStatusView order={order} comanda={comanda} onRestart={backToMenu} />
      ) : (
        <>
          <AnimatePresence>
            {notice && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="fixed left-4 right-4 top-4 z-50"
              >
                <div className="mx-auto max-w-2xl rounded-2xl border border-red-500/40 bg-red-500/15 px-4 py-3 text-sm font-semibold text-red-300 backdrop-blur-xl">
                  {notice}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          <header className="sticky top-0 z-30 border-b border-white/5 bg-coal/85 backdrop-blur-xl">
            <div className="mx-auto flex max-w-2xl items-center gap-3 px-4 py-3.5">
              <button
                onClick={() => (window.location.hash = '#/')}
                className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-zinc-300"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
              <div className="flex items-center gap-2.5">
                <img
                  src="/logo.svg"
                  alt="Logo"
                  className="h-10 w-10 drop-shadow-[0_0_14px_rgba(255,193,7,0.35)]"
                />
                <div>
                  <p className="font-display text-lg leading-none tracking-wide text-white">
                    BUTECO DO <span className="text-gold-grad">ALEMÃO</span>
                  </p>
                  <p className="text-[10px] font-medium uppercase tracking-widest text-zinc-500">
                    Cardápio digital
                  </p>
                </div>
              </div>
            </div>

            <div className="no-scrollbar flex gap-2 overflow-x-auto px-4 pb-3">
              {categories.map((cat) => {
                const active = cat.id === activeCat
                return (
                  <button
                    key={cat.id}
                    onClick={() => setActiveCat(cat.id)}
                    className={`flex shrink-0 items-center gap-1.5 rounded-full px-4 py-2 text-xs font-semibold transition ${
                      active
                        ? 'bg-gradient-to-r from-[#E50914] to-[#FF3B30] text-white shadow-glowred'
                        : 'border border-white/10 bg-white/5 text-zinc-400 hover:text-white'
                    }`}
                  >
                    <span>{cat.emoji}</span>
                    {cat.name}
                  </button>
                )
              })}
            </div>
          </header>

          <main className="mx-auto max-w-2xl px-4 pt-4">
            <motion.div
              key={activeCat}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25 }}
              className="mb-3 flex items-baseline justify-between"
            >
              <h2 className="font-display text-2xl tracking-wide text-white">
                {categories.find((c) => c.id === activeCat)?.name}
              </h2>
              <span className="text-xs text-zinc-500">{items.length} itens</span>
            </motion.div>

            {items.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-white/10 px-4 py-14 text-center">
                <p className="text-sm text-zinc-600">Nenhum item nesta categoria ainda.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                <AnimatePresence mode="popLayout">
                  {items.map((item) => {
                    const qty = cart[item.id] || 0
                    return (
                      <motion.div
                        key={item.id}
                        layout
                        initial={{ opacity: 0, scale: 0.92 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.92 }}
                        transition={{ duration: 0.2 }}
                        className="glass flex flex-col overflow-hidden rounded-2xl"
                      >
                        <div className="relative flex h-24 items-center justify-center bg-gradient-to-br from-white/[0.07] to-white/[0.02] text-5xl">
                          {item.emoji}
                          {qty > 0 && (
                            <span className="absolute right-2 top-2 flex h-6 min-w-6 items-center justify-center rounded-full bg-gradient-to-r from-[#FFC107] to-[#FF9F1A] px-1.5 text-xs font-bold text-zinc-900">
                              {qty}
                            </span>
                          )}
                        </div>
                        <div className="flex flex-1 flex-col p-3">
                          <p className="text-sm font-semibold leading-tight text-white">
                            {item.name}
                          </p>
                          <p className="mt-1 line-clamp-2 text-[11px] leading-snug text-zinc-500">
                            {item.desc}
                          </p>
                          <div className="mt-auto flex items-center justify-between pt-3">
                            <span className="text-sm font-bold text-amber-400">
                              {formatBRL(item.price)}
                            </span>
                            <button
                              onClick={() => add(item.id)}
                              className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-[#E50914] to-[#FF3B30] text-white shadow-glowred transition active:scale-90"
                            >
                              <Plus className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    )
                  })}
                </AnimatePresence>
              </div>
            )}
          </main>

          <AnimatePresence>
            {count > 0 && (
              <motion.div
                initial={{ y: 120 }}
                animate={{ y: 0 }}
                exit={{ y: 120 }}
                transition={{ type: 'spring', stiffness: 300, damping: 28 }}
                className="fixed inset-x-0 bottom-0 z-40 px-4 pb-5"
              >
                <div className="mx-auto max-w-2xl">
                  <motion.button
                    whileTap={{ scale: 0.97 }}
                    onClick={() => setSheetOpen(true)}
                    className="btn-red flex w-full items-center justify-between rounded-2xl px-5 py-4"
                  >
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <ShoppingBag className="h-6 w-6" />
                        <span className="absolute -right-2.5 -top-2.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-[#FFC107] px-1 text-[11px] font-bold text-zinc-900">
                          {count}
                        </span>
                      </div>
                      <span className="text-sm font-semibold">Ver pedido</span>
                    </div>
                    <span className="text-sm font-extrabold">{formatBRL(total)}</span>
                  </motion.button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <CartSheet
            open={sheetOpen}
            onClose={() => setSheetOpen(false)}
            items={cartItems}
            total={total}
            onRemove={remove}
            onAdd={add}
            onSubmit={handleOrder}
          />
        </>
      )}
    </div>
  )
}
