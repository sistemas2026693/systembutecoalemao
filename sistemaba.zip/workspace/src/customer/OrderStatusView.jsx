import { motion } from 'framer-motion'
import { Banknote, Beer, Check, ChefHat, PartyPopper, Phone, RotateCcw, Timer } from 'lucide-react'
import { formatBRL } from '../menu.js'

const STEPS = [
  { key: 'new', label: 'Recebido', icon: Phone },
  { key: 'preparing', label: 'Preparando', icon: ChefHat },
  { key: 'ready', label: 'Pronto', icon: PartyPopper }
]

const STATUS_TEXT = {
  new: 'Pedido recebido com sucesso!',
  preparing: 'A cozinha está preparando o seu pedido.',
  ready: 'Seu pedido está pronto! Retire no balcão.',
  delivered: 'Pedido entregue. Prost!'
}

export default function OrderStatusView({ order, comanda, onRestart }) {
  if (!order?.id) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center px-6 text-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
          className="flex h-16 w-16 items-center justify-center rounded-2xl border-2 border-amber-400/30 border-t-amber-400"
        />
        <p className="mt-6 font-display text-2xl tracking-wide text-white">ENVIANDO PEDIDO</p>
        <p className="mt-1 text-sm text-zinc-500">Aguardando confirmação do balcão…</p>
      </div>
    )
  }

  const isDelivered = order.status === 'delivered'
  const currentStep = isDelivered ? STEPS.length : STEPS.findIndex((s) => s.key === order.status)
  const progress = isDelivered ? 100 : (currentStep / STEPS.length) * 100

  return (
    <div className="flex min-h-screen flex-col px-6 pb-10 pt-12">
      <div className="pointer-events-none fixed inset-0">
        {order.status === 'ready' && (
          <div className="absolute inset-0 bg-amber-500/10 blur-[120px]" />
        )}
      </div>

      <div className="mx-auto flex w-full max-w-sm flex-1 flex-col items-center text-center">
        {comanda?.status === 'paid' && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: -10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="mb-6 w-full rounded-2xl border border-emerald-400/40 bg-emerald-400/10 px-4 py-4"
          >
            <div className="flex items-center justify-center gap-2">
              <Check className="h-5 w-5 text-emerald-400" />
              <p className="text-sm font-bold text-emerald-300">Pagamento confirmado!</p>
            </div>
            <p className="mt-1 text-xs text-emerald-200/70">
              Obrigado pela preferência. Prost!
            </p>
          </motion.div>
        )}

        {comanda?.status === 'pending' && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: -10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="mb-6 w-full rounded-2xl border border-amber-400/40 bg-amber-400/10 px-4 py-4"
          >
            <div className="flex items-center justify-center gap-2">
              <Banknote className="h-5 w-5 text-amber-400" />
              <p className="text-sm font-bold text-amber-300">Comanda fechada</p>
            </div>
            <p className="mt-1 text-xs text-amber-200/70">
              Faça o pagamento no balcão para encerrar a comanda.
            </p>
          </motion.div>
        )}

        <motion.div
          initial={{ scale: 0, rotate: -20 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: 'spring', stiffness: 260, damping: 18 }}
          className="mb-5 flex h-20 w-20 items-center justify-center rounded-[1.4rem] bg-gradient-to-br from-[#E50914] to-[#FF9F1A] shadow-glowred"
        >
          {order.status === 'ready' ? (
            <PartyPopper className="h-10 w-10 text-white" />
          ) : (
            <Beer className="h-10 w-10 text-white" />
          )}
        </motion.div>

        <p className="font-display text-4xl tracking-wide text-white">
          PEDIDO <span className="text-gold-grad">#{order.id}</span>
        </p>

        <div className="mt-1 flex items-center gap-2 text-sm text-zinc-400">
          <Timer className="h-4 w-4" />
          Mesa {order.table} · {order.customerName}
        </div>

        <motion.p
          key={order.status}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 text-sm text-zinc-300"
        >
          {STATUS_TEXT[order.status]}
        </motion.p>

        <div className="mt-8 w-full">
          <div className="flex justify-between">
            {STEPS.map((step, i) => {
              const Icon = step.icon
              const done = i < currentStep || isDelivered
              const active = i === currentStep && !isDelivered
              return (
                <div key={step.key} className="flex flex-1 flex-col items-center">
                  <div
                    className={`flex h-12 w-12 items-center justify-center rounded-2xl border transition-all ${
                      done
                        ? 'border-transparent bg-gradient-to-br from-[#FFC107] to-[#FF9F1A] text-zinc-900 shadow-neon'
                        : active
                          ? 'border-amber-400/60 bg-amber-400/10 text-amber-300'
                          : 'border-white/10 bg-white/5 text-zinc-600'
                    }`}
                  >
                    {done ? <Check className="h-6 w-6" /> : <Icon className="h-6 w-6" />}
                  </div>
                  <span
                    className={`mt-2 text-[11px] font-medium ${done || active ? 'text-amber-300' : 'text-zinc-600'}`}
                  >
                    {step.label}
                  </span>
                </div>
              )
            })}
          </div>

          <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/5">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.7, ease: 'easeOut' }}
              className="h-full rounded-full bg-gradient-to-r from-[#E50914] via-[#FF3B30] to-[#FFC107]"
            />
          </div>
        </div>

        <div className="mt-9 w-full rounded-2xl border border-white/5 bg-white/[0.03] p-4 text-left">
          <p className="mb-2 text-[11px] font-semibold uppercase tracking-widest text-zinc-500">
            Itens do pedido
          </p>
          <div className="space-y-1.5">
            {order.items.map((item) => (
              <div key={item.id} className="flex justify-between text-sm">
                <span className="text-zinc-300">
                  <span className="mr-2">{item.emoji}</span>
                  {item.qty}× {item.name}
                </span>
                <span className="text-zinc-400">{formatBRL(item.price * item.qty)}</span>
              </div>
            ))}
          </div>
          {order.notes && (
            <p className="mt-2 border-t border-white/5 pt-2 text-xs text-zinc-500">
              Obs: {order.notes}
            </p>
          )}
          <div className="mt-3 flex items-center justify-between border-t border-white/5 pt-3">
            <span className="text-sm text-zinc-400">Total</span>
            <span className="text-base font-extrabold text-amber-400">{formatBRL(order.total)}</span>
          </div>
        </div>

        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={onRestart}
          className="glass mt-7 flex items-center gap-2 rounded-2xl px-6 py-3.5 text-sm font-semibold text-white transition hover:border-amber-400/40"
        >
          <RotateCcw className="h-4 w-4 text-amber-400" />
          Fazer novo pedido
        </motion.button>
      </div>
    </div>
  )
}
